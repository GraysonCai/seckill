CREATE PROCEDURE execute_seckill(IN  v_seckill_id BIGINT, IN v_user_phone BIGINT, IN v_kill_time TIMESTAMP,
                                 OUT r_result     INT)
  BEGIN
    DECLARE result_count INT DEFAULT 0;
    START TRANSACTION;
      INSERT IGNORE INTO success_seckilled (seckill_id, user_phone) VALUES
        (v_seckill_id, v_user_phone);
      SELECT row_count() INTO result_count;
      IF(result_count = 0) THEN
        ROLLBACK;
        SET r_result = -1;
      ELSEIF(result_count < 0) THEN
        ROLLBACK;
        SET r_result = -3;
      ELSE  
        UPDATE seckill
        SET number = number - 1
        WHERE seckill_id = v_seckill_id
        AND start_time <= v_kill_time
        AND end_time >= v_kill_time
        AND number > 0;

        SELECT row_count() INTO result_count;
        IF(result_count = 0) THEN
          ROLLBACK;
          SET r_result = 0;
        ELSEIF(result_count < 0) THEN
          ROLLBACK;
          SET r_result = -3;
        ELSE
          COMMIT;
          SET r_result = 1;
        END IF;
      END IF;
    COMMIT;
  END;

